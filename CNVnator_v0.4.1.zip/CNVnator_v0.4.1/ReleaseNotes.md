New in CNVnator version 0.4.1:
* Listing content of CNVnator root file (option: -ls)
* Copying RD and SNP data to new root file (option: -cptrees)
* Python tool for whole genome circular plot of RD and BAF (plotcircular.py)
* Mask file for reference genome hg19 available in ExampleData/ (used with -mask option)
* Reading CNVnator root file using python module (pytools.io)
